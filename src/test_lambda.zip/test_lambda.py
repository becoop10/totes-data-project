import boto3

def create_lambda_function():
    client = boto3.client('lambda')
    response = client.create_function(
        FunctionName='hello-world-lambda',
        Runtime='python3.8',
        Role='',
        Handler='lambda_function.lambda_handler',
        Code={
        }
    )
    return response
def lambda_handler(event, context):
    print("Hello World")
    return {
        'statusCode': 200,
    }